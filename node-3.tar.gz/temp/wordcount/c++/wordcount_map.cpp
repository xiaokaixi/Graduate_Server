#include <iostream>
#include <string>
using namespace std;

int main(int argc,char** argv)
{
	string word;
	while (cin >> word)
	{
		cout << word << "\t" << "1" << endl;
	}
	return 0;
}